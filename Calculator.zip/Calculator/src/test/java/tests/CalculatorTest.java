package tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Date;
import java.util.concurrent.Flow.Publisher;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import pageObjects.BasicCalculatorPage;
import pageObjects.ScientificCalculatorPage;

@Listeners(utilities.ExtentReportsListener.class)
public class CalculatorTest {
	public AndroidDriver driver;
	public BasicCalculatorPage basicCal;
	public ScientificCalculatorPage scientificCal; 	
	
	@BeforeMethod
	public void setup() throws MalformedURLException 
	{
		UiAutomator2Options options=new UiAutomator2Options();
		options.setDeviceName("Gouri_phone");
		options.setAppPackage("com.android.calculator2");
		options.setAppActivity("com.android.calculator2.Calculator");
		options.setPlatformName("Android");
		driver=new AndroidDriver(new URL("http://127.0.0.1:4723/"),options);  
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		basicCal=new BasicCalculatorPage(driver);
		scientificCal=new ScientificCalculatorPage(driver);
	}

	
//	//Basic Calculation
//	
//	@Test(priority = 1)
//	public void addition()  {
//		basicCal.add();
//		assertEquals("7", basicCal.verifyResult());
//	}
//	
//	@Test(priority = 2)
//	public void subtaction() {
//		basicCal.subtract();
//		assertEquals("3", basicCal.verifyResult());
//	}
//
//	@Test(priority = 3)
//	public void multiplication() {
//		basicCal.multiply();
//		assertEquals("10", basicCal.verifyResult());
//	}
	
	
	//Scientific Calculation
	
	@Test(priority = 1)
	public void advancedCalculation() {
		scientificCal.logOperation();
		assertEquals("0", basicCal.verifyResult());
	}
	
	
	// Method to capture a screenshot of failed test cases
		@AfterMethod(groups = "checkout")
		public void captureScreenshotOfFail(ITestResult result) {
			if (result.getStatus() == ITestResult.FAILURE) {
				File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				try {
					Date d1 = new Date();
					FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

}
