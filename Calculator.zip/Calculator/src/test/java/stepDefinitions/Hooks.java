package stepDefinitions;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Base64;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;


public class Hooks {
	public static AndroidDriver driver;
	private ExtentReports extent;
	private ExtentTest test;

	@Before
	public void openApp() throws MalformedURLException{
		UiAutomator2Options options=new UiAutomator2Options();
		options.setDeviceName("Gouri_phone");
		options.setAppPackage("com.android.calculator2");
		options.setAppActivity("com.android.calculator2.Calculator");
		options.setPlatformName("Android");
		driver=new AndroidDriver(new URL("http://127.0.0.1:4723/"),options);  
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		//Initialize the Extent reports with the HTML reporter
		String repname = "CucumberReport" + getTimeStamp() + ".html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(
				System.getProperty("user.dir") + "//CucumberReports//" + repname);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
		// Create a new test
		test = extent.createTest("Calculator");

	}

	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}
	@After
	public void closeBrowser(Scenario scenario){
		if (scenario.isFailed()) {
			//Take the screenshot
			final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			//Add it to the report
			test.addScreenCaptureFromPath("data:image/png;base64," + Base64.getEncoder().encodeToString(screenshot));
		} else {
			//Take the screenshot
			final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			//Add it to the report
			test.addScreenCaptureFromPath("data:image/png;base64," + Base64.getEncoder().encodeToString(screenshot));
			test.pass("Test passed");
		}
		extent.flush();
		driver.quit();
	}
}
