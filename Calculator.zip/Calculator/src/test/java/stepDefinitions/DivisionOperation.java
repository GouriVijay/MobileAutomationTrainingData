package stepDefinitions;

import static org.testng.Assert.assertEquals;

import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.BasicCalculatorPage;
import pageObjects.ScientificCalculatorPage;
import utilities.AndroidActions;

public class DivisionOperation {
	private final AndroidDriver driver=Hooks.driver;
	public AndroidActions actions;
	public BasicCalculatorPage basicCal;
	public ScientificCalculatorPage scientificCal; 	
	
	public DivisionOperation() {
		basicCal=new BasicCalculatorPage(driver);
		scientificCal=new ScientificCalculatorPage(driver);
	}
	
	@Given("User on calculator app")
	public void user_on_calculator_app() {
	    System.out.println("user is on calculator app");
	}

	@When("User enter divident and divisor and click equals")
	public void user_enter_divident_and_divisor_and_click_equals() {
		basicCal.enterDivisor();
	    basicCal.enterDivident();
	    basicCal.equals();
	}

	@Then("User verify the result")
	public void user_verify_the_result() {
		assertEquals("5", basicCal.verifyResult());
	}

	@When("User enter divident and divisor as zero and click equals")
	public void user_enter_divident_and_divisor_as_zero_and_click_equals() {
		basicCal.enterDivisor();
	    basicCal.enterZero();
	    basicCal.equals();
	}

	@Then("User verify the error message")
	public void user_verify_the_error_message() {
		assertEquals("Can't divide by 0", basicCal.verifyResult());
	}
}