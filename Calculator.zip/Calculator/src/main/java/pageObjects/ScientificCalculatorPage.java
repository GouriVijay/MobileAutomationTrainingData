package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class ScientificCalculatorPage {
	public AndroidDriver driver;
	AndroidActions actions;
	public BasicCalculatorPage basic;
	
	public ScientificCalculatorPage(AndroidDriver driver)
	{
		this.driver= driver;
		this.actions=new AndroidActions(driver); 
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(accessibility = "Advanced operations")
	WebElement advanced;
	@AndroidFindBy(accessibility = "logarithm")
	WebElement log;
	@FindBy(id="com.android.calculator2:id/digit_1")
	WebElement one;
	@FindBy(id="com.android.calculator2:id/digit_0")
	WebElement zero;
	@AndroidFindBy(accessibility = "right parenthesis")
	WebElement rightParenthesis;
	@AndroidFindBy(accessibility = "power")
	WebElement power;
	@FindBy(id="com.android.calculator2:id/digit_2")
	WebElement two;
	@AndroidFindBy(accessibility = "equals")
	WebElement equals;
	@FindBy(id="com.android.calculator2:id/result")
	WebElement result;
	
	
	public void AdvancedOperations() {
		advanced.click();
	}
	
	public void logOperation() {
		actions.swipeAction(advanced, "left");
		log.click();
		actions.swipeAction(advanced, "right");
		one.click();
		zero.click();
		actions.swipeAction(advanced, "left");
		rightParenthesis.click();
		power.click();
		actions.swipeAction(advanced, "right");
		two.click();
		equals.click();		
	}
	
	public String verifyResult() {
		return result.getText();
	}


}
