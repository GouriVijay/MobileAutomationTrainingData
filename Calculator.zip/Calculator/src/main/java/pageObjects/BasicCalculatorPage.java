package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.mongodb.connection.ConnectionId;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class BasicCalculatorPage {
	public AndroidDriver driver;
	AndroidActions actions;
	
	public BasicCalculatorPage(AndroidDriver driver)
	{
		this.driver= driver;
		this.actions=new AndroidActions(driver); 
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@FindBy(id="com.android.calculator2:id/digit_5")
	WebElement five;
	@FindBy(id="com.android.calculator2:id/digit_2")
	WebElement two;
	@FindBy(id="com.android.calculator2:id/digit_1")
	WebElement one;
	@FindBy(id="com.android.calculator2:id/digit_0")
	WebElement zero;
	@AndroidFindBy(accessibility = "minus")
	WebElement minus;
	@AndroidFindBy(accessibility = "plus")
	WebElement plus;
	@AndroidFindBy(accessibility = "multiply")
	WebElement multiply;
	@AndroidFindBy(accessibility = "divide")
	WebElement divide;
	@AndroidFindBy(accessibility = "equals")
	WebElement equals;
	@AndroidFindBy(accessibility = "clear")
	WebElement clear;	
	@FindBy(id="com.android.calculator2:id/result")
	WebElement result;
	
	
	public void add() {
		five.click();
		plus.click();
		two.click();
		equals.click();
	}
	 
	public void subtract() {
		five.click();
		minus.click();
		two.click();
		equals.click();
	}
	
	public void multiply() {
		five.click();
		multiply.click();
		two.click();
		equals.click();
	}	
	
	public void enterDivisor() {
		one.click();
		zero.click();
		divide.click();
	}
	
	public void enterDivident() {
		two.click();
	}
	
	public void enterZero() {
		zero.click();
	}
	
	public void equals() {      
		equals.click();
	}
	
	public String verifyResult() {
		return result.getText();
	}

}
