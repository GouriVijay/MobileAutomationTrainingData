package pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class Login {
    private final Page page;
    private final Locator username;
    private final Locator password;
    private final Locator loginButton;
	public Login(Page page) {
		super();
		this.page = page;
		this.username = page.locator("#user");
		this.password = page.locator("#pass");
		this.loginButton = page.locator("#name=submit");
	}
    
	public void navigateTo(String url)
	{
		page.navigate(url);
	}
	
	public void enterUsername(String uname)
	{
		username.fill(uname);
	}
	public void enterPassword(String pwd)
	{
		password.fill(pwd);
	}
	public void clickLogin()
	{
		loginButton.click();
	}
   
    

}
