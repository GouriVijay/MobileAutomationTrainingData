package pageObjects;

import java.util.List;

import org.jsoup.internal.ReturnsAreNonnullByDefault;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class AlarmPage {
	public AndroidDriver driver;
	AndroidActions actions;
	
	public AlarmPage(AndroidDriver driver)
	{
		this.driver= driver;
		this.actions=new AndroidActions(driver); 
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(accessibility = "Alarm")
	WebElement alarm;
	@AndroidFindBy(accessibility = "Add alarm")
	WebElement addAlarm;
	@AndroidFindBy(accessibility = "1 o'clock")
	WebElement setHour;
	@AndroidFindBy(accessibility = "50 minutes")
	WebElement setMinute;
	@AndroidFindBy(id = "com.google.android.deskclock:id/material_clock_period_am_button")
	WebElement setMeridian;
	@FindBy(id = "com.google.android.deskclock:id/material_timepicker_ok_button")
	WebElement ok;
	@AndroidFindBy(accessibility = "1:50 AM")
	WebElement verifyAddAlarm;
	@FindBy(xpath = "(//android.widget.ImageButton[@content-desc=\"Expand alarm\"])[1]")
	WebElement dropdown;
	@FindBy(id = "com.google.android.deskclock:id/delete")
	WebElement delete;
	@AndroidFindBy(className ="android.widget.ImageButton")
	List<WebElement> setOfAlarm;
	@AndroidFindBy( accessibility = "8:30 AM")
	WebElement editAlarm;
	
	
	public void clickAlarm() {
		alarm.click();
	}
	public void addAlarm() {
		addAlarm.click();
		setHour.click();
		setMinute.click();
		setMeridian.click();
		ok.click();
		}
	public String verifyAdd() {
		return verifyAddAlarm.getText();
	}
	public void deleteAlarm() {
		dropdown.click();
		delete.click();
	}
	public int verifyDelete() {
		return setOfAlarm.size();
		
	}
	
	//cucumber
	public void editAlarm()
	{
		dropdown.click();
		editAlarm.click();
		setHour.click();
		setMinute.click();
		setMeridian.click();
		ok.click();
	}
	public String verifyEdit() {
		return verifyAddAlarm.getText();
	}

}
