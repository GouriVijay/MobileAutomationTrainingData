package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class ClockPage {
	public AndroidDriver driver;
	AndroidActions actions;
	
	public ClockPage(AndroidDriver driver)
	{
		this.driver= driver;
		this.actions=new AndroidActions(driver); 
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	@AndroidFindBy(accessibility = "Clock")
	WebElement clickClock;
	@AndroidFindBy(accessibility = "Add city")
	WebElement addCity;
	@FindBy(id = "com.google.android.deskclock:id/open_search_view_edit_text")
	WebElement searchbar;
	@FindBy(id = "com.google.android.deskclock:id/city_name")
	WebElement selectCity;
	@FindBy(id = "com.google.android.deskclock:id/city_name")
	WebElement verifyCity;
	
	
	public void clickClock() {
		clickClock.click();
	}
	
	public void clickAddCity() {
		addCity.click();
	}
	
	public void selectCity(String city) {
		searchbar.sendKeys(city);
		selectCity.click();
	}
	
	public String verifyAddCity() {
		return verifyCity.getText();
	}


}
