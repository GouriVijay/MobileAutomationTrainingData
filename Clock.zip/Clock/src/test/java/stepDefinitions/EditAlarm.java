package stepDefinitions;

import static org.testng.Assert.assertEquals;

import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.AlarmPage;
import utilities.AndroidActions;

public class EditAlarm {
	private final AndroidDriver driver=Hooks.driver;
	public AlarmPage alarmPage;
	public AndroidActions actions;
	
	@Given("User click on alarm clock to edit time")
	public void user_click_on_alarm_clock_to_edit_time() {
	    alarmPage=new AlarmPage(driver);
	    alarmPage.clickAlarm();
	}

	@When("User enter time as {string} and click ok")
	public void user_enter_time_as_and_click_ok(String string) {
		 alarmPage=new AlarmPage(driver);
		 alarmPage.editAlarm();
	}

	@Then("Alarm time is edited")
	public void alarm_time_is_edited() {
		 alarmPage=new AlarmPage(driver);
		 assertEquals(alarmPage.verifyEdit(), "1:50 AM");
	}


}
