package stepDefinitions;

import static org.testng.Assert.assertEquals;

import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.ClockPage;
import utilities.AndroidActions;

public class AddClock {
	private final AndroidDriver driver=Hooks.driver;
	public ClockPage clockPage;
	public AndroidActions actions;
	
	@Given("User already on clockApp")
	public void user_already_on_clock_app() {
	   clockPage=new ClockPage(driver);
	   clockPage.clickClock();
	}

	@When("User click on add city")
	public void user_click_on_add_city() {
		clockPage=new ClockPage(driver);
		clockPage.clickAddCity();
	}

	@When("User enter {string} as city on searchbar and click on city")
	public void user_enter_as_city_on_searchbar_and_click_on_city(String string) {
		clockPage=new ClockPage(driver);
		clockPage.selectCity(string);
	}

	@Then("clock of specified city is added")
	public void clock_of_specified_city_is_added() {
		clockPage=new ClockPage(driver);
		assertEquals("Amsterdam", clockPage.verifyAddCity());
	}

}
