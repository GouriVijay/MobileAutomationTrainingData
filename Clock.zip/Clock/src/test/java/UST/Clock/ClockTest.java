package UST.Clock;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.logging.NeedsLocalLogs;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import pageObjects.AlarmPage;
import pageObjects.ClockPage;

@Listeners(utilities.ExtentReportsListener.class)
public class ClockTest {

	public AndroidDriver driver;
	public AlarmPage alarmPage;
	public ClockPage clockPage;

	@BeforeMethod
	public void setup() throws MalformedURLException 
	{
		UiAutomator2Options options=new UiAutomator2Options();
		options.setDeviceName("Gouri_phone");
		options.setAppPackage("com.google.android.deskclock");
		options.setAppActivity("com.android.deskclock.DeskClock");
		options.setPlatformName("Android");
		driver=new AndroidDriver(new URL("http://127.0.0.1:4723/"),options);  
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		alarmPage=new AlarmPage(driver);
		clockPage=new ClockPage(driver);
	}

	@Test(priority = 1)
	public void setAlarm() {
		alarmPage.clickAlarm();
		alarmPage.addAlarm();
		assertEquals("1:50 AM", alarmPage.verifyAdd());
	}

	@Test(priority = 2)
	public void deleteAlarm() throws InterruptedException {
		alarmPage.clickAlarm();
		alarmPage.deleteAlarm();
		Thread.sleep(1000);
		assertEquals(alarmPage.verifyDelete(),1);		
	}

	@Test(priority = 3)
	public void addCity() throws InterruptedException {
		clockPage.clickClock();
		clockPage.clickAddCity();
		Thread.sleep(1000);
		assertEquals("Amsterdam", clockPage.verifyAddCity());
	}


	// Method to capture a screenshot of failed test cases
	@AfterMethod(groups = "checkout")
	public void captureScreenshotOfFail(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				Date d1 = new Date();
				FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
