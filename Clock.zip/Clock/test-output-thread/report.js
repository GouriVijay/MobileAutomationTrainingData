$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"21f8f3c7-78c5-4213-afa1-73d49d63dcfa","feature":"AddClock","scenario":"add clock of new city","start":1717148754034,"group":1,"content":"","tags":"@addclock,@positive,","end":1717148774629,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});