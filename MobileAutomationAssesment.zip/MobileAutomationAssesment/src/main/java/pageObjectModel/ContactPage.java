package pageObjectModel;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.ReusableFunctions;

public class ContactPage {

	public AndroidDriver driver;
	ReusableFunctions actions;

	public ContactPage(AndroidDriver driver)
	{
		this.driver= driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	//locators to locate different elements

	@FindBy(id="android:id/button2")
	WebElement skipSignin;
	@FindBy(id="com.android.permissioncontroller:id/permission_allow_button")
	WebElement allowNotification;
	@FindBy(id="com.google.android.contacts:id/floating_action_button")
	WebElement create;	
	@FindBy(id="com.google.android.contacts:id/large_title")
	WebElement verifyName;

	@AndroidFindBy(id="com.google.android.contacts:id/navigation_bar_item_active_indicator_view")
	WebElement clickContacts;


	@AndroidFindBy(className = "android.view.ViewGroup")
	List<WebElement> delNum;
	@AndroidFindBy(accessibility = "More options")
	WebElement moreOpt;
	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")
	WebElement delete;
	@AndroidFindBy(id = "android:id/button1")
	WebElement confirmDel;
	@AndroidFindBy(id="com.google.android.contacts:id/attribution_header")
	WebElement numOfContacts;

	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"arathi G\"]")
	WebElement selectContact;
	@AndroidFindBy(accessibility = "Edit contact")
	WebElement edit;
	@FindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.EditText")
	WebElement company;
	@FindBy(id ="com.google.android.contacts:id/toolbar_button")
	WebElement save;
	@AndroidFindBy(id = "com.google.android.contacts:id/organization_name")
	WebElement companyName;	


	//method to open contacts app by clicking skip and allowing notification
	public void openApp() {
		skipSignin.click();
		allowNotification.click();
	}

	//verify name of contact
	public String verifyName() {
		return verifyName.getText();
	}

	//method to click on contact icon
	public void clickContact() {
		clickContacts.click();
	}

	//method to delete contact
	public void deleteContact()
	{
		delNum.get(2).click();
		moreOpt.click();
		delete.click();
		confirmDel.click();
	}

	// verify contact is deleted
	public int verifyDelete() {
		String[] s= numOfContacts.getText().split(" ");
		String s1 = s[2];
		int i = Integer.parseInt(s1);
		return i;		
	}

	//method to select specific contact
	public void selectContact() {
		clickContacts.click();
		selectContact.click();
	}

	//method to edit contact
	public void editContact(String cname) {
		edit.click();
		company.sendKeys(cname);
		save.click();
	}

	//method to verify company name
	public String verifyCompany() {
		return companyName.getText();
	}

}
