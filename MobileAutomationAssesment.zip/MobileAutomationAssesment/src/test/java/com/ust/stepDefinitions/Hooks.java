package com.ust.stepDefinitions;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Base64;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utilities.ReusableFunctions;

public class Hooks {
	public static AndroidDriver driver;
	public static ExtentReports extent;
	public ExtentTest test;
	static {
		// Initialize ExtentReports only once
		String repname = "CucumberReport" + getTimeStamp() + ".html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(
				System.getProperty("user.dir") + "//CucumberReports//" + repname);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}

	@Before
	public void setup(Scenario scenario) throws MalformedURLException {
		driver = ReusableFunctions.invokeApplication();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		// Create a new test
		test = extent.createTest(scenario.getName());
	}

	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}

	@After
	public void closeBrowser(Scenario scenario) {
		if (scenario.isFailed()) {
			saveScreenshot(scenario, "failed");
			test.fail("Test failed");
		} else {
			saveScreenshot(scenario, "passed");
			test.pass("Test passed");
		}
		extent.flush();
		driver.quit();
	}

	private void saveScreenshot(Scenario scenario, String status) {
		// Take the screenshot
		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String scenarioName = scenario.getName().replaceAll(" ", "_");
		String timeStamp = getTimeStamp();
		String screenshotName = scenarioName + "_" + timeStamp + ".png";
		// Define the path where the screenshot will be saved
		String directory = System.getProperty("user.dir") + "//CucumberScreenshots//" + status + "//";
		File destFile = new File(directory + screenshotName);
		// Create directories if they do not exist
		new File(directory).mkdirs();
		try {
			// Copy the screenshot to the destination path
			FileUtils.copyFile(screenshot, destFile);
			// Add screenshot to the report
			test.addScreenCaptureFromPath(destFile.getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
