package com.ust.stepDefinitions;

import static org.testng.Assert.assertEquals;

import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjectModel.ContactPage;
import utilities.ReusableFunctions;

public class editContacts {

	private final AndroidDriver driver=Hooks.driver;
	public ContactPage contacts;
	public ReusableFunctions reusable;

	@Given("User already on contact page")
	public void user_already_on_contact_page() {
		contacts=new ContactPage(driver);
		contacts.openApp();
	}

	@When("User select the contact that need to be edited")
	public void user_select_the_contact_that_need_to_be_edited() {
		contacts=new ContactPage(driver);
		contacts.selectContact();
	}

	@When("User click edit and enter {string} as company and save")
	public void user_click_edit_and_enter_as_company_and_save(String string) {
		contacts=new ContactPage(driver);
		contacts.editContact(string);
	}

	@Then("verify edited company name")
	public void verify_edited_company_name() {
		assertEquals(contacts.verifyCompany(),"ust");
	}

}
