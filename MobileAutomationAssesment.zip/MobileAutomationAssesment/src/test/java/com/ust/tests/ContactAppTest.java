package com.ust.tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import pageObjectModel.ContactPage;
import pageObjectModel.CreateContactPage;
import utilities.ExtentReportsListener;
import utilities.ReusableFunctions;

@Listeners(utilities.ExtentReportsListener.class)
public class ContactAppTest {
	public AndroidDriver driver;
	public ReusableFunctions reusable;
	public ContactPage contacts;
	public CreateContactPage newContact;

	@BeforeMethod(groups= {"create","delete"})
	public void setup() throws MalformedURLException {
		driver = ReusableFunctions.invokeApplication(); //method to invoke application
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		reusable = new ReusableFunctions(driver);
		ExtentReportsListener.setDriver(driver);
		contacts = new ContactPage(driver);
		newContact = new CreateContactPage(driver);
	}

	// DataProvider for test data   
	// fetching data from json file
	@DataProvider(name = "jsondata")
	public Object[] getData() throws IOException {
		List<HashMap<String, String>> list = ReusableFunctions
				.getJsonData(System.getProperty("user.dir") + "\\src\\test\\resources\\jsonData\\data.json");
		return list.toArray();
	}
	
    //test to create a new contact
	@Test(priority = 1, dataProvider = "jsondata",groups = "create")
	public void createContact(HashMap<String, String> map) {
		contacts.openApp();
		newContact.createNewContact(map.get("First_name"), map.get("Last_name"), map.get("Company"), map.get("Phone"));
		assertEquals(contacts.verifyName(), map.get("Full_name"));  //verify contact name of created contact

	}
	
    //test to delete a contact
	@Test(priority = 2,groups = "delete")
	public void deleteContact() {
		contacts.openApp();
		int ContactsBeforeDeletion = contacts.verifyDelete(); //number of contacts before deletion
		contacts.clickContact();
		contacts.deleteContact();
		int ContactsAfterDeletion = contacts.verifyDelete(); // number of contacts after deletion
		assertEquals(ContactsBeforeDeletion - 1, ContactsAfterDeletion); //verify if contact is deleted
	}

	//method to capture screenshot of failed test
	@AfterMethod(groups= {"create","delete"})
	public void captureScreenshotOfFail(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				Date d1 = new Date();
				FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
