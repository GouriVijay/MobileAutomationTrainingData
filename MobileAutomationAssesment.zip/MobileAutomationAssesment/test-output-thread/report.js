$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"7e4cf25e-7fa6-4eec-b457-cb79861ed0bd","feature":"editContact","scenario":"edit an existing contact","start":1718348955987,"group":1,"content":"","tags":"@editcontact,@positive,","end":1718348984315,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});