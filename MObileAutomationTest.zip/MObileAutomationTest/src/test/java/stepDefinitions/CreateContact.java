package stepDefinitions;

public class CreateContact {
	

}
