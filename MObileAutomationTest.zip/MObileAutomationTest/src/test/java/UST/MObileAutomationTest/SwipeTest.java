package UST.MObileAutomationTest;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import utilities.AndroidActions;

public class SwipeTest {
	public class ScrollTest1 {
		public AndroidDriver driver;
		public AndroidActions actions;
		
		@BeforeMethod
		public void setup() throws MalformedURLException 
		{
			UiAutomator2Options options=new UiAutomator2Options();
			options.setDeviceName("Gouri_phone");
			options.setApp("C:\\Users\\269657\\MobileAutomation\\MObileAutomationTest\\src\\test\\resources\\apk\\ApiDemos-debug.apk");
			options.setPlatformName("Android");
			driver=new AndroidDriver(new URL("http://127.0.0.1:4723/"),options);  
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			actions=new AndroidActions(driver);
		}
		
		@Test
		public void swipe() {
			driver.findElement(AppiumBy.accessibilityId("Views")).click();
			driver.findElement(AppiumBy.accessibilityId("Gallery")).click();
			driver.findElement(AppiumBy.accessibilityId("1. Photos")).click();
			WebElement element1=driver.findElement(AppiumBy.xpath("/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.Gallery/android.widget.ImageView[1]"));
			actions.swipeAction(element1,"left");
			WebElement element2=driver.findElement(AppiumBy.xpath("/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.Gallery/android.widget.ImageView[3]"));
			actions.swipeAction(element2, "right");
		}
	}
}
