package UST.MObileAutomationTest;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;

public class ScrollTest extends BaseTest {

	@Test
	public void test() {
		driver.findElement(AppiumBy.accessibilityId("Views")).click();

		// new scrollable object allows you to scroll through list or scroll view
		// scrollintoview method scrolls through ui until it finds a view with specific
		// text

		driver.findElement(
				AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"WebView\"));"));
		scrolltoEndAction();
	}

	public void scrolltoEndAction() {
		// boolean variable will be used to determine if more scrolling is possible
		boolean canScrollmore;
		// loop to scroll down until no more scrolling possible
		do {
			// scrollgestre is a command in appium that performs scroll gesture on screen
			// The gesture starts from point (100, 100) with a width of 200 and height of
			// 200.
			// in downward direction
			// 3.0 is how much you want to scroll as percentage
			canScrollmore = (Boolean) ((JavascriptExecutor) driver).executeScript("mobile.scrollGesture", ImmutableMap
					.of("left", 100, "top", 100, "width", 200, "height", 200, "direction", "down", "percent", 3.0));
		} while (canScrollmore);
	}
}
