package pageObjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Factory;

import io.appium.java_client.android.AndroidDriver;

public class MessagePage {
	public AndroidDriver driver;
	public MessagePage(AndroidDriver driver)
	{
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="com.google.android.apps.messaging:id/conversation_list_spam_popup_positive_button")
    WebElement okBtn;
	@FindBy( id =  "com.google.android.apps.messaging:id/start_chat_fab")
	WebElement startChat;
	@FindBy(id = "com.google.android.apps.messaging:id/recipient_text_view")
	WebElement searchElement;
	@FindBy(id = "com.google.android.apps.messaging:id/compose_message_text")
	WebElement Text;
	@FindBy(xpath = "//android.widget.ImageView[@content-desc=\"Send SMS\"]")
	WebElement send;
	
	public void clickStartChat()
	{
		okBtn.click();
		startChat.click();
	}
	public void clickSearch() {
		searchElement.sendKeys("9633187161");
		Actions actions =new Actions(driver);
		actions.sendKeys(searchElement,Keys.ENTER).build().perform();
	}
	public void enterText() {
		Text.sendKeys("How Are You");
	}
	public void clickSend() {
		send.click();
	}
	

}
