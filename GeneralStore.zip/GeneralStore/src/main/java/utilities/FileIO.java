package utilities;
import java.io.FileInputStream;
import java.util.Properties;
public class FileIO {
	 private static Properties properties;
	    // Method to retrieve properties from config file
	    public static Properties getProperties() {
	        // Check if properties object is null
	        if (properties == null) {
	            properties = new Properties();
	            try {
	                // Load properties from config file
	                FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\ObjectRepository\\cofig.properties");
	                properties.load(fis);
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	        return properties;
	    }
	
}