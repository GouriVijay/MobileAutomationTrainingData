package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import utilities.AndroidActions;

public class HomePage {
	public AndroidDriver driver;
	AndroidActions actions;
	
	public HomePage(AndroidDriver driver)
	{
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="com.androidsample.generalstore:id/spinnerCountry")
    WebElement selectCountry;
	@FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[10]")
	WebElement india;
	
	public void clickCountry()
	{
		actions=new AndroidActions(driver);
		selectCountry.click();
		actions.scrollToText("India");
		india.click();
		
	}

}
