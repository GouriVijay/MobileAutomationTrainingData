package UST.GeneralStore;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import pageObjects.HomePage;
import utilities.AndroidActions;

public class GeneralStoreTest {
	public AndroidDriver driver;
	public AndroidActions actions;

	@BeforeMethod
	public void setup() throws MalformedURLException 
	{
		UiAutomator2Options options=new UiAutomator2Options();
		options.setDeviceName("Gouri_phone");
		options.setApp("C:\\Users\\269657\\MobileAutomation\\GeneralStore\\src\\test\\resources\\apk\\General-Store.apk");
		options.setPlatformName("Android");
		driver=new AndroidDriver(new URL("http://127.0.0.1:4723/"),options);  
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		actions=new AndroidActions(driver);
	}
	
	@Test
	public void homeTest() {
	    HomePage homePage=new HomePage(driver);
	    homePage.clickCountry();
	}

}
