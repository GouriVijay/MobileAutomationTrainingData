$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"06fd32fd-ec14-42cf-be04-637a1130f75b","feature":"createContact","scenario":"create a contact","start":1716801362376,"group":1,"content":"","tags":"@createcontact,@positive,","end":1716801396834,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});