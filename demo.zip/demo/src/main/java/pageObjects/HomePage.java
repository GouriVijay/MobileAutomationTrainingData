package pageObjects;

import java.util.List;

import org.apache.logging.log4j.util.StringBuilderFormattable;
import org.jsoup.internal.FieldsAreNonnullByDefault;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import utilities.AndroidActions;

public class HomePage {
	public AndroidDriver driver;
	AndroidActions actions;
	
	public HomePage(AndroidDriver driver)
	{
		this.driver= driver;
		this.actions=new AndroidActions(driver); 
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@FindBy(id="android:id/button2")
	WebElement skipSignin;
	@FindBy(id="com.android.permissioncontroller:id/permission_allow_button")
	WebElement allowNotification;
	@FindBy(id="com.google.android.contacts:id/floating_action_button")
    WebElement create;	
	@FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.FrameLayout/android.widget.EditText")
	WebElement firstname;
	@FindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.EditText")
	WebElement lastname;
	@FindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.EditText")
	WebElement company;
	@FindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.ScrollView/android.widget.LinearLayout/android.view.ViewGroup/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[3]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.EditText")
	WebElement phone;
	@FindBy(id ="com.google.android.contacts:id/toolbar_button")
	WebElement save;
	@AndroidFindBy(accessibility = "Edit contact")
	WebElement edit;
	@AndroidFindBy(id = "com.google.android.contacts:id/organization_name")
	WebElement companyName;	
	@AndroidFindBy(accessibility = "Gouri vijay")
	WebElement select;
	@FindBy(id="com.google.android.contacts:id/large_title")
	WebElement verifyName;
	@AndroidFindBy(id="com.google.android.contacts:id/attribution_header")
	WebElement numOfContacts;
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"arathi G\"]")
	WebElement selectContact;
	@AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Hilu\"]")
	WebElement selectContact1;
	@FindBy(className = "android.widget.TextView")
	List<WebElement>  elements;
	@AndroidFindBy(id="com.google.android.contacts:id/navigation_bar_item_active_indicator_view")
	WebElement contacts;
	@AndroidFindBy(className  = "android.view.ViewGroup")
	List<WebElement> delNum;
	@AndroidFindBy(accessibility  = "More options")
	WebElement moreOpt;
	@AndroidFindBy(xpath  = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")
	WebElement delete;
	@AndroidFindBy(id  = "android:id/button1")
	WebElement confirmDel;
	@AndroidFindBy(id="com.google.android.contacts:id/open_search_bar_text_view")
	WebElement searchbar;
	@AndroidFindBy(className ="android.widget.EditText")
	List<WebElement> searchText;
	
	
	
//	@FindBy(className = "android.widget.EditText")
//	List<WebElement>  elements;
//	public void editFirstName(String first) {
//		elements.get(1).sendKeys(first);
//	}
	
	
	
	public void contacts() {
		skipSignin.click();
		allowNotification.click();
	}
	
	public void createNewContact(String first,String last,String company1,String phone1)
	{
		
		create.click();
		firstname.sendKeys(first);
		lastname.sendKeys(last);
		company.sendKeys(company1);
		phone.sendKeys(phone1);
		save.click();
		
	}
	
	public void editContact() {
        edit.click();
        company.sendKeys("ibm");
        save.click();
	}
	
	public String verifyCompany() {
		return companyName.getText();
	}
	
	public void clickContact() {
		contacts.click();
	}
	public void selectContact() {
		contacts.click();
		selectContact.click();
	}
	
	public void deleteContact()
	{
		delNum.get(2).click();
		moreOpt.click();
		delete.click();
		confirmDel.click();
	}
	public int verifyDelete() {
		String[] s= numOfContacts.getText().split(" ");
		String s1 = s[2];
		int i = Integer.parseInt(s1);
		return i;		
	}
	
	public void searchContact() {
		searchbar.click();
		searchText.get(0).sendKeys("arathi");
		AndroidActions.tap(driver, 407, 407);
	}
	

	
	
	/*  ***   cucumber  ***  */
	
	public void clickNewContact(){
		create.click();
	}
	public void createContact(String fname,String lname,String num) {
        firstname.sendKeys(fname);
        lastname.sendKeys(lname);
        phone.sendKeys(num);
        save.click();
    }
	public String verifyName() {
		return verifyName.getText();
	}
	

}
