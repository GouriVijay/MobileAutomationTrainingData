package UST.Contacts;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import pageObjects.HomePage;
import utilities.AndroidActions;

//@Listeners(utilities.ExtentReportsListener.class)
public class ContactsTest {
	public AndroidDriver driver;
	public HomePage home;

	@BeforeMethod
	public void setup() throws MalformedURLException 
	{
		UiAutomator2Options options=new UiAutomator2Options();
		options.setDeviceName("Gouri_phone");
		options.setAppPackage("com.google.android.contacts");
		options.setAppActivity("com.android.contacts.activities.PeopleActivity");
		options.setPlatformName("Android");
		driver=new AndroidDriver(new URL("http://127.0.0.1:4723/"),options);  
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		home=new HomePage(driver);
		

	}
	
	@DataProvider(name="jsondata")
	public Object[] getData() throws IOException {
		List<HashMap<String,String>> list  = AndroidActions.getJsonData(System.getProperty("user.dir")+"\\src\\test\\resources\\testData\\jsonData.json");
		return list.toArray();
	}

	
	@Test(priority = 1,dataProvider = "jsondata")
	public void createContact(HashMap<String, String> map) {
		home.contacts();
		home.createNewContact(map.get("First_name"),map.get("Last_name"),map.get("Company"),map.get("Phone"));
		assertEquals(home.verifyName(),"Gouri Vijay");
		
	}

	@Test(priority = 2)
	public void editContact() {
		home.contacts();
		home.selectContact();
		home.editContact();
		assertEquals(home.verifyCompany(),"ibm");
		}
	
	
	@Test(priority = 3)
    public void deleteContact() {
    	home.contacts();
    	int ContactsBeforeDeletion=home.verifyDelete();
    	home.clickContact();
    	home.deleteContact();
    	int ContactsAfterDeletion=home.verifyDelete();
    	assertEquals(ContactsBeforeDeletion -1,ContactsAfterDeletion );
    }
	
	@Test(priority = 4)
	public void searchContact() {
		home.contacts();
		home.clickContact();
		home.searchContact();
		assertEquals(home.verifyName(),"arathi G");
	}

	 // Method to capture a screenshot of failed test cases
	@AfterMethod(groups = "checkout")
	public void captureScreenshotOfFail(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				Date d1 = new Date();
				FileUtils.copyFile(screenshot, new File("FailedScreenshots/" + d1.getTime() + "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
