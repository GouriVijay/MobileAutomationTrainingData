package stepDefinitions;

import static org.testng.Assert.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.HomePage;
import utilities.AndroidActions;

public class CreateContact {
	private final AndroidDriver driver=Hooks.driver;
	public HomePage home;
	public AndroidActions actions;
	
	@Given("User already on contact page")
	public void user_already_on_contact_page() {
		home=new HomePage(driver);
		home.contacts();
	}

	@When("User click on create contact")
	public void user_click_on_create_contact() {
		home=new HomePage(driver);
		home.clickNewContact();
	}

	@When("User enter {string} as firstname {string} as lastname {string} as phone and save")
	public void user_enter_as_firstname_as_lastname_as_phone_and_save(String string, String string2, String string3) {
	  home=new HomePage(driver);
	  home.createContact(string, string2, string3);
	}

	@Then("New contact created")
	public void new_contact_created() {
		home=new HomePage(driver);
		assertEquals(home.verifyName(),"arathi G");
	}


}
